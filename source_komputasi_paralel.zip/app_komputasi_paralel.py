import os
import sys
import time
import math
import numpy as np
from PIL import Image
import streamlit as st
import pandas as pd

# Konfigurasi Path DLL CUDA Toolkit Lokal untuk Numba
base_dir = os.path.dirname(os.path.abspath(__file__))
cuda_path = os.path.join(base_dir, "cuda_toolkit")
if os.path.exists(cuda_path):
    os.environ["CUDA_HOME"] = cuda_path
    os.environ["PATH"] = cuda_path + ";" + os.environ.get("PATH", "")

# Import Numba
from numba import njit, prange, set_num_threads, cuda

# Konfigurasi Tampilan Halaman Streamlit
st.set_page_config(
    page_title="Benchmark Komputasi Paralel Konvolusi Citra",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Inisialisasi Kernel Numba CPU Multi-Core
@njit(parallel=True, fastmath=True)
def conv_cpu_parallel(img, k):
    h, w = img.shape
    kh, kw = k.shape
    pad_h = kh // 2
    pad_w = kw // 2
    out = np.zeros((h, w), dtype=np.float32)
    
    for r in prange(pad_h, h - pad_h):
        for c in range(pad_w, w - pad_w):
            val = 0.0
            for i in range(kh):
                for j in range(kw):
                    val += img[r - pad_h + i, c - pad_w + j] * k[i, j]
            out[r, c] = val
    return out

@njit(parallel=True, fastmath=True)
def sobel_cpu_parallel(img):
    h, w = img.shape
    out = np.zeros((h, w), dtype=np.float32)
    
    # Kernel Sobel Gx dan Gy 3x3
    for r in prange(1, h - 1):
        for c in range(1, w - 1):
            gx = (img[r-1, c+1] + 2.0*img[r, c+1] + img[r+1, c+1]) - \
                 (img[r-1, c-1] + 2.0*img[r, c-1] + img[r+1, c-1])
            gy = (img[r+1, c-1] + 2.0*img[r+1, c] + img[r+1, c+1]) - \
                 (img[r-1, c-1] + 2.0*img[r-1, c] + img[r-1, c+1])
            out[r, c] = math.sqrt(gx * gx + gy * gy)
    return out

# Inisialisasi Kernel Numba GPU CUDA
@cuda.jit
def sobel_gpu_kernel(d_img, d_out, h, w):
    r, c = cuda.grid(2)
    if 1 <= r < h - 1 and 1 <= c < w - 1:
        gx = (d_img[r-1, c+1] + 2.0*d_img[r, c+1] + d_img[r+1, c+1]) - \
             (d_img[r-1, c-1] + 2.0*d_img[r, c-1] + d_img[r+1, c-1])
        gy = (d_img[r+1, c-1] + 2.0*d_img[r+1, c] + d_img[r+1, c+1]) - \
             (d_img[r-1, c-1] + 2.0*d_img[r-1, c] + d_img[r-1, c+1])
        d_out[r, c] = math.sqrt(gx * gx + gy * gy)

# Metode Interpolasi untuk Upscaling
METODE_NEAREST, METODE_BILINEAR, METODE_BICUBIC = 0, 1, 2
metode_labels = {
    METODE_NEAREST: "Nearest Neighbor",
    METODE_BILINEAR: "Bilinear",
    METODE_BICUBIC: "Bicubic (Catmull-Rom)"
}

# Bobot kernel Catmull-Rom
# ponytail: @njit tidak bisa dipanggil dari @cuda.jit, jadi dibuat dua versi
@njit(cache=True, fastmath=True)
def cubic_weight(t):
    t = abs(t)
    if t < 1.0:
        return 1.5 * t * t * t - 2.5 * t * t + 1.0
    elif t < 2.0:
        return -0.5 * t * t * t + 2.5 * t * t - 4.0 * t + 2.0
    return 0.0

@cuda.jit(device=True)
def cubic_weight_gpu(t):
    t = abs(t)
    if t < 1.0:
        return 1.5 * t * t * t - 2.5 * t * t + 1.0
    elif t < 2.0:
        return -0.5 * t * t * t + 2.5 * t * t - 4.0 * t + 2.0
    return 0.0

# Konvensi koordinat pusat sel (center-aligned), sama seperti PIL/OpenCV,
# sehingga hasil CPU dan GPU dapat dibandingkan dengan referensi PIL.
@njit(parallel=True, fastmath=True)
def resize_cpu_parallel(src, out_h, out_w, method):
    in_h, in_w = src.shape
    out = np.zeros((out_h, out_w), dtype=np.float32)
    # ponytail: skala per-sumbu, bukan area ratio; tepat untuk resize seragam
    sy = in_h / out_h
    sx = in_w / out_w

    for oy in prange(out_h):
        for ox in range(out_w):
            fy = (oy + 0.5) * sy - 0.5
            fx = (ox + 0.5) * sx - 0.5
            if method == METODE_NEAREST:
                iy = min(max(int(math.floor(fy + 0.5)), 0), in_h - 1)
                ix = min(max(int(math.floor(fx + 0.5)), 0), in_w - 1)
                out[oy, ox] = src[iy, ix]
            elif method == METODE_BILINEAR:
                iy = int(math.floor(fy))
                ix = int(math.floor(fx))
                ty = fy - iy
                tx = fx - ix
                val = 0.0
                wsum = 0.0
                for dj in range(2):
                    wy = (1.0 - ty) if dj == 0 else ty
                    sj = min(max(iy + dj, 0), in_h - 1)
                    for di in range(2):
                        wx = (1.0 - tx) if di == 0 else tx
                        si = min(max(ix + di, 0), in_w - 1)
                        val += src[sj, si] * wx * wy
                        wsum += wx * wy
                out[oy, ox] = val / wsum
            else:
                iy = int(math.floor(fy))
                ix = int(math.floor(fx))
                ty = fy - iy
                tx = fx - ix
                val = 0.0
                wsum = 0.0
                for j in range(-1, 3):
                    wy = cubic_weight(ty - j)
                    sj = min(max(iy + j, 0), in_h - 1)
                    for i in range(-1, 3):
                        wx = cubic_weight(tx - i)
                        si = min(max(ix + i, 0), in_w - 1)
                        val += src[sj, si] * wx * wy
                        wsum += wx * wy
                out[oy, ox] = val / wsum
    return out

@cuda.jit
def resize_gpu_kernel(d_src, d_out, out_h, out_w, method, sy, sx):
    oy, ox = cuda.grid(2)
    if oy >= out_h or ox >= out_w:
        return
    in_h, in_w = d_src.shape
    fy = (oy + 0.5) * sy - 0.5
    fx = (ox + 0.5) * sx - 0.5
    if method == 0:
        iy = min(max(int(math.floor(fy + 0.5)), 0), in_h - 1)
        ix = min(max(int(math.floor(fx + 0.5)), 0), in_w - 1)
        d_out[oy, ox] = d_src[iy, ix]
    elif method == 1:
        iy = int(math.floor(fy))
        ix = int(math.floor(fx))
        ty = fy - iy
        tx = fx - ix
        val = 0.0
        wsum = 0.0
        for dj in range(2):
            wy = (1.0 - ty) if dj == 0 else ty
            sj = min(max(iy + dj, 0), in_h - 1)
            for di in range(2):
                wx = (1.0 - tx) if di == 0 else tx
                si = min(max(ix + di, 0), in_w - 1)
                val += d_src[sj, si] * wx * wy
                wsum += wx * wy
        d_out[oy, ox] = val / wsum
    else:
        iy = int(math.floor(fy))
        ix = int(math.floor(fx))
        ty = fy - iy
        tx = fx - ix
        val = 0.0
        wsum = 0.0
        for j in range(-1, 3):
            wy = cubic_weight_gpu(ty - j)
            sj = min(max(iy + j, 0), in_h - 1)
            for i in range(-1, 3):
                wx = cubic_weight_gpu(tx - i)
                si = min(max(ix + i, 0), in_w - 1)
                val += d_src[sj, si] * wx * wy
                wsum += wx * wy
        d_out[oy, ox] = val / wsum

@cuda.jit
def conv_gpu_kernel(d_img, d_k, d_out, h, w, kh, kw):
    r, c = cuda.grid(2)
    pad_h = kh // 2
    pad_w = kw // 2
    if pad_h <= r < h - pad_h and pad_w <= c < w - pad_w:
        val = 0.0
        for i in range(kh):
            for j in range(kw):
                val += d_img[r - pad_h + i, c - pad_w + j] * d_k[i, j]
        d_out[r, c] = val

# Pre-compile JIT Warm-up
@st.cache_resource
def warm_up_jit():
    dummy = np.zeros((32, 32), dtype=np.float32)
    k_dummy = np.zeros((3, 3), dtype=np.float32)
    set_num_threads(1)
    _ = conv_cpu_parallel(dummy, k_dummy)
    _ = sobel_cpu_parallel(dummy)
    _ = resize_cpu_parallel(dummy, 64, 64, METODE_BICUBIC)

    cuda_available = False
    try:
        d_in = cuda.to_device(dummy)
        d_out = cuda.device_array((32, 32), dtype=np.float32)
        sobel_gpu_kernel[(2, 2), (16, 16)](d_in, d_out, 32, 32)
        d_out2 = cuda.device_array((64, 64), dtype=np.float32)
        resize_gpu_kernel[(2, 2), (16, 16)](d_in, d_out2, 64, 64, METODE_BICUBIC, 0.5, 0.5)
        cuda.synchronize()
        cuda_available = True
    except Exception as e:
        cuda_available = False
    return cuda_available

cuda_status = warm_up_jit()

# Header Aplikasi
st.title("⚡ Dasbor Benchmark Komputasi Paralel Konvolusi Citra")
st.markdown("""
Aplikasi pengujian performansi komputasi paralel filter konvolusi citra resolusi tinggi.
Membandingkan skalabilitas pemrosesan **CPU Multi-Core (1, 2, 4, 8 Core)** dan **GPU NVIDIA CUDA**.
""")

def run_cpu(img, op, filt, meth, out_h, out_w):
    """Eksekusi kernel CPU pada citra masukan. Mengembalikan array hasil 2D float32."""
    if op == "Upscaling Citra":
        return resize_cpu_parallel(img, out_h, out_w, meth)
    if filt == "Sobel Edge Detection":
        return sobel_cpu_parallel(img)
    return conv_cpu_parallel(img, kernel_dict[filt])

def gpu_blocks(h, w):
    tpb = (16, 16)
    return (math.ceil(h / tpb[1]), math.ceil(w / tpb[0])), tpb

def run_gpu(d_in, d_out, h, w, op, filt, meth, out_h, out_w, sy, sx):
    """Eksekusi kernel GPU. d_in/d_out sudah dialokasikan pemanggil."""
    if op == "Upscaling Citra":
        grid, tpb = gpu_blocks(out_h, out_w)
        resize_gpu_kernel[grid, tpb](d_in, d_out, out_h, out_w, meth, sy, sx)
    else:
        grid, tpb = gpu_blocks(h, w)
        if filt == "Sobel Edge Detection":
            sobel_gpu_kernel[grid, tpb](d_in, d_out, h, w)
        else:
            d_k = cuda.to_device(kernel_dict[filt])
            conv_gpu_kernel[grid, tpb](d_in, d_k, d_out, h, w, 3, 3)
    cuda.synchronize()

# Sidebar: Pengaturan Uji
st.sidebar.header("⚙️ Konfigurasi Pengujian")

# Pemilihan Citra
source_option = st.sidebar.radio(
    "Sumber Citra:",
    ["Dataset Resolusi Standar", "Unggah Berkas Citra"]
)

img_loaded = None
img_name = ""

preset_files = {
    "Peppers 1080p (Full HD - 1920x1080)": os.path.join(base_dir, "peppers_1080p.png"),
    "Peppers 4K (4K UHD - 3840x2160)": os.path.join(base_dir, "peppers_4k.png"),
    "Peppers 8K (8K UHD - 7680x4320)": os.path.join(base_dir, "peppers_8k.png")
}

if source_option == "Dataset Resolusi Standar":
    selected_preset = st.sidebar.selectbox("Pilih Resolusi Citra:", list(preset_files.keys()))
    path_preset = preset_files[selected_preset]
    if os.path.exists(path_preset):
        img_loaded = Image.open(path_preset).convert('L')
        img_name = selected_preset
    else:
        st.sidebar.warning(f"Berkas preset {selected_preset} tidak ditemukan di scratch.")
else:
    uploaded_file = st.sidebar.file_uploader("Unggah Citra (PNG, JPG):", type=["png", "jpg", "jpeg"])
    if uploaded_file is not None:
        img_loaded = Image.open(uploaded_file).convert('L')
        img_name = uploaded_file.name

# Pemilihan Operasi Komputasi
operation = st.sidebar.selectbox(
    "Pilih Operasi Komputasi:",
    ["Filter Konvolusi Spasial", "Upscaling Citra"]
)

# Pemilihan Filter Konvolusi
filter_type = None
method_code = METODE_BICUBIC
target_size = None

if operation == "Filter Konvolusi Spasial":
    filter_type = st.sidebar.selectbox(
        "Pilih Filter Spasial:",
        ["Sobel Edge Detection", "Gaussian Blur 3x3", "Sharpening 3x3"]
    )
else:
    method_code = st.sidebar.selectbox(
        "Pilih Metode Interpolasi:",
        list(metode_labels.keys()),
        format_func=lambda m: metode_labels[m]
    )
    target_size = st.sidebar.selectbox(
        "Resolusi Target Upscaling:",
        ["4K UHD (3840x2160)", "8K UHD (7680x4320)"]
    )

# Definisi Matriks Kernel Spasial
kernel_dict = {
    "Gaussian Blur 3x3": (1.0 / 16.0) * np.array([
        [1.0, 2.0, 1.0],
        [2.0, 4.0, 2.0],
        [1.0, 2.0, 1.0]
    ], dtype=np.float32),
    "Sharpening 3x3": np.array([
        [ 0.0, -1.0,  0.0],
        [-1.0,  5.0, -1.0],
        [ 0.0, -1.0,  0.0]
    ], dtype=np.float32)
}

# Mode Eksekusi
exec_mode = st.sidebar.selectbox(
    "Mode Eksekusi Pemrosesan:",
    ["Benchmark Komprehensif (Semua Core & GPU)", "Pengujian Satuan (Core Tertentu / GPU)"]
)

single_target = "CPU 1 Core"
if exec_mode == "Pengujian Satuan (Core Tertentu / GPU)":
    options = ["CPU 1 Core", "CPU 2 Cores", "CPU 4 Cores", "CPU 8 Cores"]
    if cuda_status:
        options.append("GPU NVIDIA CUDA")
    single_target = st.sidebar.selectbox("Pilih Unit Pemroses:", options)

# Status CUDA Hardware
st.sidebar.markdown("---")
st.sidebar.markdown("### 🖥️ Status Perangkat Keras")
st.sidebar.write("• **CPU:** Intel Core 5 210H (8 Physical Cores, 12 Threads)")
if cuda_status:
    st.sidebar.success("• **GPU:** NVIDIA RTX 3050 CUDA Siap (2.560 Cores)")
else:
    st.sidebar.error("• **GPU:** CUDA Tidak Terdeteksi / Driver Bermasalah")

# Eksekusi Pemrosesan
if img_loaded is not None:
    img_arr = np.array(img_loaded, dtype=np.float32)
    h, w = img_arr.shape
    total_pixels = h * w
    
    st.info(f"📁 Citra Aktif: **{img_name}** | Dimensi: **{w} x {h}** piksel ({total_pixels:,} elemen matriks)")

    # Hitung dimensi target upscaling
    if operation == "Upscaling Citra":
        if target_size.startswith("4K"):
            out_w, out_h = 3840, 2160
        else:
            out_w, out_h = 7680, 4320
        if out_w == w and out_h == h:
            st.warning(f"Citra masukan sudah beresolusi {w}x{h}. Pilih resolusi target lain atau unggah citra lebih kecil.")
            st.stop()
        if out_w < w or out_h < h:
            st.warning(f"Upscaling ke {out_w}x{out_h} tidak mungkin dari citra {w}x{h}. Pilih resolusi target lebih tinggi.")
            st.stop()
        sy = h / out_h
        sx = w / out_w
        st.info(f"📈 Target: **{out_w} x {out_h}** piksel ({out_h * out_w:,} elemen) | Metode: **{metode_labels[method_code]}**")
    else:
        out_w, out_h = w, h
        sy = sx = 1.0

    col_btn, _ = st.columns([1, 4])
    start_btn = col_btn.button(f"🚀 Jalankan {operation}", type="primary")
    
    if start_btn:
        st.subheader("📊 Hasil Pengujian dan Perbandingan Performa")
        
        # Eksekusi Satuan
        if exec_mode == "Pengujian Satuan (Core Tertentu / GPU)":
            with st.spinner(f"Memproses konvolusi pada {single_target}..."):
                res_img = None
                t_exec = 0.0
                
                if "CPU" in single_target:
                    cores = int(single_target.split()[1])
                    set_num_threads(cores)
                    t0 = time.perf_counter()
                    res_img = run_cpu(img_arr, operation, filter_type, method_code, out_h, out_w)
                    t_exec = time.perf_counter() - t0
                else: # GPU CUDA
                    t0 = time.perf_counter()
                    d_in = cuda.to_device(img_arr)
                    d_out = cuda.device_array((out_h, out_w), dtype=np.float32)
                    run_gpu(d_in, d_out, h, w, operation, filter_type, method_code,
                            out_h, out_w, sy, sx)
                    res_img = d_out.copy_to_host()
                    t_exec = time.perf_counter() - t0

                # Normalisasi hasil gambar
                res_norm = np.clip(res_img, 0, 255).astype(np.uint8)
                
                # Tampilkan Kartu Metrik
                out_pixels = out_h * out_w
                c1, c2, c3 = st.columns(3)
                c1.metric("Unit Pemroses", single_target)
                c2.metric("Waktu Eksekusi", f"{t_exec:.4f} detik", f"{1000*t_exec:.1f} ms")
                c3.metric("Throughput", f"{(out_pixels / (t_exec * 1e6)):.2f} MPiksel/detik")

                # Tampilan Citra Sebelum & Sesudah Berdampingan
                st.markdown("### 🖼️ Visualisasi Sebelum dan Sesudah")
                im_col1, im_col2 = st.columns(2)
                im_col1.image(img_loaded, caption=f"Citra Asli ({w}x{h})", use_container_width=True)
                im_col2.image(res_norm, caption=f"Hasil {operation} ({single_target})", use_container_width=True)

        else: # Benchmark Lengkap Semua Konfigurasi
            with st.spinner("Menjalankan benchmark paralel bertingkat (1, 2, 4, 8 Core CPU & GPU CUDA)..."):
                bench_results = []
                last_result_img = None
                
                # Uji CPU 1, 2, 4, 8 Cores
                t1_baseline = None
                for c in [1, 2, 4, 8]:
                    set_num_threads(c)
                    t0 = time.perf_counter()
                    res = run_cpu(img_arr, operation, filter_type, method_code, out_h, out_w)
                    dur = time.perf_counter() - t0
                    last_result_img = res

                    if c == 1:
                        t1_baseline = dur
                    
                    speedup = t1_baseline / dur
                    eff = (speedup / c) * 100.0
                    bench_results.append({
                        "Unit Pemroses": f"CPU {c} Core{'s' if c > 1 else ''}",
                        "Waktu (detik)": dur,
                        "Waktu (ms)": dur * 1000.0,
                        "Speedup": speedup,
                        "Efisiensi (%)": eff,
                        "Kategori": "CPU Multi-Core"
                    })
                
                # Uji GPU CUDA
                if cuda_status:
                    # Ukur Kernel murni vs Total transfer
                    t_start_total = time.perf_counter()
                    d_in = cuda.to_device(img_arr)
                    d_out = cuda.device_array((out_h, out_w), dtype=np.float32)

                    # Waktu kernel murni
                    t_start_kernel = time.perf_counter()
                    run_gpu(d_in, d_out, h, w, operation, filter_type, method_code,
                            out_h, out_w, sy, sx)
                    t_dur_kernel = time.perf_counter() - t_start_kernel

                    # Salin balik ke host
                    res_gpu = d_out.copy_to_host()
                    t_dur_total = time.perf_counter() - t_start_total
                    last_result_img = res_gpu

                    bench_results.append({
                        "Unit Pemroses": "GPU CUDA (Kernel Murni)",
                        "Waktu (detik)": t_dur_kernel,
                        "Waktu (ms)": t_dur_kernel * 1000.0,
                        "Speedup": t1_baseline / t_dur_kernel,
                        "Efisiensi (%)": 0.0,
                        "Kategori": "GPU CUDA"
                    })
                    bench_results.append({
                        "Unit Pemroses": "GPU CUDA (Total I/O PCIe)",
                        "Waktu (detik)": t_dur_total,
                        "Waktu (ms)": t_dur_total * 1000.0,
                        "Speedup": t1_baseline / t_dur_total,
                        "Efisiensi (%)": 0.0,
                        "Kategori": "GPU CUDA"
                    })
                
                df_res = pd.DataFrame(bench_results)
                
                # Tampilkan Tabel
                st.dataframe(
                    df_res.style.format({
                        "Waktu (detik)": "{:.4f}",
                        "Waktu (ms)": "{:.1f}",
                        "Speedup": "{:.2f}x",
                        "Efisiensi (%)": "{:.1f}%"
                    }),
                    use_container_width=True
                )
                
                # Tampilkan Grafik Batang
                col_g1, col_g2 = st.columns(2)
                
                with col_g1:
                    st.markdown("#### ⏱️ Waktu Eksekusi (Milidetik - Makin Rendah Makin Cepat)")
                    chart_time = df_res.set_index("Unit Pemroses")[["Waktu (ms)"]]
                    st.bar_chart(chart_time)
                    
                with col_g2:
                    st.markdown("#### 🚀 Rasio Percepatan (Speedup Relatif terhadap CPU 1 Core)")
                    chart_spd = df_res.set_index("Unit Pemroses")[["Speedup"]]
                    st.bar_chart(chart_spd)
                
                # Tampilan Citra Sebelum & Sesudah Berdampingan
                st.markdown("### 🖼️ Visualisasi Sebelum dan Sesudah")
                res_norm = np.clip(last_result_img, 0, 255).astype(np.uint8)
                im_c1, im_c2 = st.columns(2)
                im_c1.image(img_loaded, caption=f"Citra Asli ({w}x{h})", use_container_width=True)
                im_c2.image(res_norm,
                            caption=f"Hasil {operation} ({filter_type or metode_labels[method_code]})",
                            use_container_width=True)

                # Metrik kualitas hasil upscaling vs referensi Lanczos PIL
                if operation == "Upscaling Citra" and last_result_img is not None:
                    # ponytail: bicubic Catmull-Rom overshoot ~1% piksel; diratakan
                    # ke rentang uint8 agar MSE/PSNR konsisten dengan referensi PIL
                    hasil = np.clip(last_result_img, 0, 255)
                    ref = np.array(img_loaded.resize((out_w, out_h), Image.Resampling.LANCZOS),
                                   dtype=np.float32)
                    mse = float(np.mean((hasil - ref) ** 2))
                    if mse > 0:
                        psnr = float(20.0 * math.log10(255.0 / math.sqrt(mse)))
                    else:
                        psnr = float('inf')
                    st.markdown("#### 🔍 Kualitas Hasil Upscaling")
                    st.write(f"MSE terhadap referensi Lanczos PIL: **{mse:.4f}** | "
                             f"PSNR: **{psnr:.2f} dB** (metode {metode_labels[method_code]})")

                # Opsi Unduh Log CSV
                csv_data = df_res.to_csv(index=False).encode('utf-8')
                nama_op = (filter_type or metode_labels[method_code]).lower().replace(' ', '_')
                st.download_button(
                    label="📥 Unduh Data Benchmark (CSV)",
                    data=csv_data,
                    file_name=f"benchmark_{operation.split()[0].lower()}_{nama_op}_{w}x{h}_ke_{out_w}x{out_h}.csv",
                    mime="text/csv"
                )

else:
    st.info("Silakan pilih resolusi citra standar atau unggah citra pada panel kiri untuk memulai pengujian.")
